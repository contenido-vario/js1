class Alumno {
    constructor (nombre, apellido, genero, nacionalidad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.nacionalidad = nacionalidad;
    }

    // irán mil cosas mas...

    toString() { 
        return `<b>${this.nombre} ${this.apellido}</b> es ${(this.genero==='M'? 'hombre': 'mujer')}, y nació en <em>${this.nacionalidad}</em>`
    }
}