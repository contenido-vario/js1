const alumnos = [
    new Alumno(
        'Aya',
        'Ouadari',
        'F',
        'Marruecos'
    ),
    new Alumno('Cristian','Rengifo','M','Perú'),
    new Alumno('Cyrille','Nyami','M','Camerún'),
    new Alumno('David','Campo','M','México'),
    new Alumno('Jenifer','Gonzalez','F','España'),
    new Alumno('Joelle','Moussi','F','Camerún'),
    new Alumno('Maximiliam','Dostmann','M','Deutchland'),
    new Alumno('Mohamed','Zakhbat','M','Marruecos'),
    new Alumno('Naomi','Quito','F','España'),
    new Alumno('Natalia','Yanovich','F','Bielorussia'),
    new Alumno('Yolanda','Fontanillas','F','República Catalana'),
    new Alumno('Yordano','Gil','M','Venezuela'),
]