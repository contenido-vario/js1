//1 MAPEOS
const MOSTRAR = document.getElementById('mostrar');
const RESULTADO = document.getElementById('resultado');

//2 VARIABLES Y FUNCIONES
const mostrarDatos = () => {
    RESULTADO.innerHTML = alumnos.join('<br>');
}

//3 ESCUCHADORES
MOSTRAR.addEventListener('click', mostrarDatos);

//4 RESTO DEL PROGRAMA